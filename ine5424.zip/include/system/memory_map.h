// EPOS Memory Map

#ifndef __memory_map_h
#define __memory_map_h

#include <system/config.h>
#include __HEADER_MMOD(memory_map)

#endif
