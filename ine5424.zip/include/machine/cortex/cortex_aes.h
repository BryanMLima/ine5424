// EPOS ARM Cortex AES Mediator Declarations

#ifndef __cortex_aes_h
#define __cortex_aes_h

#include <machine/aes.h>

__BEGIN_SYS

// TODO: this is just a place holder. Replace with Cortex-A AES!
template<unsigned int KEY_SIZE>
class HWAES;

__END_SYS

#endif
