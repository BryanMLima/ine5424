// EPOS PC Display Mediator Implementation

#include <system/config.h>

#ifdef __DISPLAY_H

#include <machine/display.h>

__BEGIN_SYS

// Class attributes
VGA::Frame_Buffer VGA::_frame_buffer;

__END_SYS

#endif
