// EPOS No_MMU Mediator Implementation

#include <architecture/mmu.h>

__BEGIN_SYS

No_MMU::List No_MMU::_free;

__END_SYS
